from math import log
import operator

def calcShannonEnt(dataSet):
	'''计算给定数据集的香农熵'''
	#获取数据集的总样本数
	numEntries = len(dataSet)
	#构建一个数据字典
	labelCounts = {}
	for featVec in dataSet:
		#获取次样本的标签
		currentLable = featVec[-1]
		#如果没有这个标签类别就添加一个
		if currentLable not in labelCounts.keys():
			labelCounts[currentLable] = 0
		#把相应标签的出现的次数加1
		labelCounts[currentLable] += 1
	#初始化香农熵
	shannonEnt = 0.0
	for key in labelCounts:
		#获取相应标签的概率
		prob = float(labelCounts[key])/numEntries
		#计算香农熵
		shannonEnt -= prob * log(prob,2)
	return shannonEnt

def createDataSet():
	'''创建测试数据'''
	dataSet = [[1,1,'yes'],[1,1,'yes'],[1,0,'no'],[0,1,'no'],[0,1,'no'],]
	labels = ['no surfacing', 'flippers']
	return dataSet, labels
	
def splitDataSet(dataSet, axis, value):
	'''按照给定的特征划分数据集，待划分的数据集、划分数据集的特征(索引值)、需要返回的特征值'''
	retDataSet = []
	for featVec in dataSet:
		#如果次样本对应的特征的值是value就执行下面的操作
		if featVec[axis] == value:
			#先将次样本在axis之前的特征取出来，放到reduceFeatVec里
			reduceFeatVec = featVec[:axis]
			#再将axis之后的特征值取出来追加到reduceFeatVec里，其实就是一个去掉了目标特征值的样本
			reduceFeatVec.extend(featVec[axis+1:])
			#最后再把这个样本加入到数据集中
			retDataSet.append(reduceFeatVec)
	return retDataSet
	
def chooseBestFeatureToSplit(dataSet):
	'''选择最好的数据集划分方式，返回的是相应的索引值'''
	#获取特征值的个数
	numFeatures = len(dataSet[0]) - 1
	#获取初始的数据集香农熵
	baseEntropy = calcShannonEnt(dataSet)
	bestInfoGain = 0.0
	bestFeature = -1
	for i in range(numFeatures):
		#获取相应特征的标签
		featList = [example[i] for example in dataSet]
		#创建唯一的分类标签列表
		uniqueVals = set(featList)
		newEntropy = 0.0
		for value in uniqueVals:
			#对数据集进行分类
			subDataSet = splitDataSet(dataSet,i,value)
			#计算分类的后的数据集与原数据集比例
			prob = len(subDataSet)/float(len(dataSet))
			#得到最后的香农熵
			newEntropy += prob * calcShannonEnt(subDataSet)
		infoGain = baseEntropy - newEntropy
		if infoGain > bestInfoGain :
			bestInfoGain = infoGain
			bestFeature = i
	return bestFeature
	
def majorityCnt(classList):
	'''多数表决的方法决定子叶的类别，并返回类别标签'''
	classCount = {}
	for vote in classList:
		if vote not in classCount.keys():
			classCount[vote] = 0
		classCount[vote] += 1
	sortedClassCount = sorted(classCount.items(),key = operator.itemgetter(1), reverse=True)
	return sortedClassCount[0][0]
	
def createTree(dataSet,labels):
	'''创建决策树的函数，采用了递归的算法'''
	#获取数据集最后一列的分类标签值
	classList = [example[-1] for example in dataSet]
	#类别完全相同时停止划分，并返回相应的类别标签
	if classList.count(classList[0]) == len(classList):
		return classList[0]
	#遍历完所有特征时返回出现次数最多的类别
	if len(dataSet[0]) == 1:
		return majorityCnt(classList)
	#获取最佳特征的索引值
	bestFeat = chooseBestFeatureToSplit(dataSet)
	bestFeatLabel = labels[bestFeat]
	#根据以最佳特征值为key，构建字典树
	myTree = {bestFeatLabel:{}}
	#去除最佳特征的标签
	del(labels[bestFeat])
	#获取最佳特征的所有属性值，也就是一列
	featValues = [example[bestFeat] for example in dataSet]
	#构建唯一标签集合
	uniqueVals = set(featValues)
	for value in uniqueVals:
		#拷贝一个标签值，labels是数据集中所有特征的标签（名称、描述）
		subLabels = labels[:]
		#递归调用此函数构建树
		myTree[bestFeatLabel][value] = createTree(splitDataSet(dataSet,bestFeat,value),subLabels)
	return myTree
	
def classify(inputTree, featLabels, testVec):
	firstStr = list(inputTree.keys())[0]
	secondDict = inputTree[firstStr]
	#将标签字符转换成索引
	featIndex = featLabels.index(firstStr)
	for key in secondDict.keys():
		if testVec[featIndex] == key:
			if type(secondDict[key]).__name__ == 'dict':
				classLabel = classify(secondDict[key], featLabels, testVec)
			else: classLabel = secondDict[key]
	return classLabel
	
def storeTree(inputTree, fileName):
	import pickle
	fw = open(fileName, 'wb')
	pickle.dump(inputTree,fw)
	fw.close()

def grabTree(fileName):
	import pickle
	fr = open(fileName,'rb')
	return pickle.load(fr)